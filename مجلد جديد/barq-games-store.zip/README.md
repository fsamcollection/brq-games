# متجر برق للألعاب ⚡

قالب متجر ألعاب جاهز للنشر على **Vercel** باستخدام **Next.js (App Router)** و **TailwindCSS** — بواجهة عربية RTL.

## البدء
```bash
npm i
npm run dev
# ثم افتح http://localhost:3000
```

## النشر على Vercel
1. أنشئ مشروعًا جديدًا واختر هذا المجلد.
2. الأوامر الافتراضية تكفي:
   - Install Command: `npm i`
   - Build Command: `npm run build`
   - Output Directory: `.next`
3. اربط الدومين الخاص بك من لوحة Vercel.

## تخصيص المنتجات
حرر الملف: `data/products.json` وأضف منتجاتك وصورك الخاصة داخل `public/images`.

> هذا القالب تعليمي/استعراضي، بوابة الدفع غير مفعلة. يمكنك لاحقًا دمج مزود دفع مثل Tap/Stripe.

