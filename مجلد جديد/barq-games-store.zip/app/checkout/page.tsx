"use client";

import { useCart } from "@/components/cart/CartContext";
import { useState } from "react";

export default function Checkout() {
  const { items, clear } = useCart();
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">تم استلام طلبك ✅</h1>
        <p className="opacity-80">هذه صفحة تجريبية. يمكنك ربط بوابة دفع لاحقًا.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">إتمام الشراء</h1>
      <form
        className="card grid grid-cols-1 md:grid-cols-2 gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          clear();
          setDone(true);
        }}
      >
        <input className="rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-2" placeholder="الاسم الكامل" required />
        <input className="rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-2" placeholder="البريد الإلكتروني" type="email" required />
        <input className="rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-2" placeholder="البلد / المدينة" required />
        <input className="rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-2" placeholder="العنوان" required />
        <input className="rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-2" placeholder="الهاتف" required />
        <button className="btn md:col-span-2" type="submit">إرسال الطلب</button>
      </form>
    </div>
  );
}
