import Link from "next/link";
import Image from "next/image";
import { allProducts } from "@/lib/products";
import { ProductCard } from "@/components/ProductCard";

export default async function Home() {
  const products = await allProducts();
  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-2xl border border-neutral-800">
        <Image src="/images/hero.png" alt="برق" width={1200} height={600} className="w-full h-[260px] object-cover" priority />
        <div className="p-6 md:p-10">
          <h1 className="text-3xl md:text-4xl font-extrabold">متجر برق للألعاب ⚡</h1>
          <p className="opacity-80 mt-2">اشترِ الألعاب الرقمية والكلاسيكية بسهولة وأمان — تجربة عربية سريعة وخفيفة.</p>
          <div className="mt-4 flex gap-3">
            <Link className="btn" href="/catalog">تصفح المتجر</Link>
            <Link className="px-4 py-2 rounded-2xl border border-neutral-700 hover:bg-neutral-800" href="/about">تعرف علينا</Link>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">الأكثر شعبية</h2>
          <Link className="hover:text-brand text-sm" href="/catalog">عرض الكل</Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {products.map(p => <ProductCard key={p.id} p={p} />)}
        </div>
      </section>
    </div>
  );
}
